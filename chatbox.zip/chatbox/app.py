from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pymysql

# DB config using dedicated user
DB_HOST = "localhost"
DB_USER = "log_user"
DB_PASSWORD = "LogUserPass123!"
DB_NAME = "user_logs_db"

# Connect to MariaDB
conn = pymysql.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASSWORD,
    database=DB_NAME,
    cursorclass=pymysql.cursors.DictCursor
)

app = FastAPI()

class UserLog(BaseModel):
    user_id: int
    action_type: str
    message: str

@app.post("/logs/")
def create_log(log: UserLog):
    try:
        with conn.cursor() as cursor:
            sql = "INSERT INTO user_logs (user_id, action_type, message) VALUES (%s, %s, %s)"
            cursor.execute(sql, (log.user_id, log.action_type, log.message))
            conn.commit()
        return {"status": "success", "message": "Log inserted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
